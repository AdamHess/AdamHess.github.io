%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STFT_music Function
%  [STFT_out times N_padding] = STFT_Music(music, Fs, wTime,
%  Percent_overlap,ZP_exp)
%   Computes the STFT for a music signal using a hamming window for each
%   set of samples taken.
%   Outputs:
%   STFT_out is the complex output for the STFT in the range +/- Pi
%   times corresponds to the times associated with the center of each
%   window
%   N_padding is the number of points of zero padding used 
%   Inputs:
%   music is them music signal whose windows are to be taken
%   Fs is the sampling rate of the windows
%   wTime is the time range of the stft windows (number of points are
%   rounded down)
%   Percent_overlap is the percentage overlap between stft windows (written as an integar)
%   ZP_exp is the power of 2 of zero padding desired for FFT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function  [STFT_out times N_padding] = STFT_Music(music, Fs, wTime, Percent_overlap,ZP_exp)
%number of STFT samples per STFT slice
N_window = floor(wTime*Fs); 
%Number of overlaping points
window_overlap =floor(N_window* (Percent_overlap/100)); 
wTime = N_window/Fs;


%% preprocessing manupulation
%makes sure the music signal is only one channel
music = sum(music,2); 
%normalize music signal
music = music/max(abs(music)); 

%% Size Checking
%make sure there are an integer number of windows, if not zero pad until
%they are 

[music_length mus_c] = size(music);
number_of_windows = floor((music_length-N_window)/(N_window-window_overlap));%determins the number of times -1 that the overlaping window will fit the music length
number_of_points_left =  music_length - (N_window + number_of_windows*(N_window-window_overlap)); %determin the remainder
number_of_padding = (N_window-window_overlap)-number_of_points_left; %calculate the number of points neede to pad
music = cat(1 ,music,zeros(number_of_padding,1)); %append the zeros to the end of the signal
clear number_of_windows number_of_points_left number_of_padding

number_of_windows = floor((music_length-N_window)/(N_window-window_overlap)) +1;


%% STFT
%create hamming window
windowing = hamming(N_window);
%calculate the amount of desired zero padding
N_padding = 2^(nextpow2(N_window)+ZP_exp); 
parfor k = 1:number_of_windows
     %define the starting and ending indicies for each window of STFT
   starting = (k-1)*(N_window -window_overlap) +1;
    ending = starting+N_window-1;
    %Define the Time of the window, i.e., the center of window
    times(k) = (starting + ceil(N_window/2))/Fs;
    %apply windowing function
    frame_sample = music(starting:ending).*windowing; 
    %take FFT of sample and apply zero padding
    F_trans = fft(frame_sample,N_padding);
    %store FFT data for later
    STFT_out(:,k) = F_trans;   
end
end
