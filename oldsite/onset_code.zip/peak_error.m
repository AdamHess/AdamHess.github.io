%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [correct false_pos num_correct_onset num_FP] = peak_error(onset_times,
% actual_onsets,wTime)
% Returns the percentage error and false positives between onset times
% Outputs:
% correct - percentage of correct onsets
% false_pos - percentage of false positives detected
% num_correct_onset - returns the number of correct onsets
% num_FP - returns the number of false positve
% Inputs:
% onset_times - the time of an onset detected via various algorithms
% actual_onsets - the prenotated onsets that are known before processing
% wTime - the time used for each STFT window
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [correct false_pos num_correct_onset num_FP] = peak_error(onset_times, actual_onsets,wTime)
%initialize matricies
correct_onset_time = [];
false_positive= [];
marked_onsets(1:length(actual_onsets)) = 0;

%for each onset
for k = 1:length(onset_times)
    %find absolute distance between detected onset and onset list
   time_dist = abs(actual_onsets - onset_times(k)); 
    %find the closest onset
   [close_time Index] =  min(time_dist); 
   %if the smallest distance is within one windowlength and hasnt been detected
  if (((wTime/2) >= close_time) && (marked_onsets(Index) == 0))    
        %mark it as a correct onset
        correct_onset_time(k) = onset_times(k); 
        %mark the onset as being used so double counting does not occur
        marked_onsets(Index) = 1;   else
        %otherwise it is a false positive
        false_positive(k) = onset_times(k); 
    end
end

%due to indexing isolate all correct onsets
correct_onset_time = correct_onset_time(find(correct_onset_time>0)); 
%isolate all false positive
false_positive = false_positive(find(false_positive>0));

%count the number of false positives
num_FP = length(false_positive);
% count the number of detected onsets
num_onset = length(onset_times);
%count the number od actual onsets
num_act_onset = length(actual_onsets);
%count the number of correct onsets
num_correct_onset = length(correct_onset_time);

%calculate false postive error percentage
false_pos = (num_FP)/num_onset;
%calculate correct onset error percentage
correct = num_correct_onset/num_act_onset;
end
 