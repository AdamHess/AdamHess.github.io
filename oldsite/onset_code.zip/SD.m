%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [detection_function times] = SD(STFT_in, times_in)
%  Outputs:
%  detection_function returns the values of the detection function applied
%  at times.
%  times are the times correspoinding to the detection_function features
%       times is a modified form of times_in, multiple initial points are
%       lost due to the initial conditions needed for the detection
%       algorithm.
% Inputs:
% STFT_in is the complexted domain STFT of the music signal
%       Rows represent the kth frequency bin
%       Columns represent the order in time the STFT was taken
% times_in are the corresponding times of the center of the STFT window
%      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



function [detection_function times] = SD(STFT_in, times_in)

%% STFT

[nr nc ] = size(STFT_in);

%% Spectrial Difference
F_transform = abs(STFT_in);
times = times_in(2:end);
parfor k = 1:nc-1
    Spect_Diff_temp = F_transform(:,k+1) - F_transform(:,k);
    Spect_Diff_temp = ((Spect_Diff_temp + abs(Spect_Diff_temp))/2).^2;
    detection_function(k) = sum(Spect_Diff_temp,1);
end
end

