%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[detection_function times] = HFC(STFT_in, times_in, Fs, N_padding)
%  Outputs:
%  detection_function returns the values of the detection function applied
%  at times.
%  times are the times correspoinding to the detection_function features
%       times is a modified form of times_in, multiple initial points are
%       lost due to the initial conditions needed for the detection
%       algorithm.
% Inputs:
% STFT_in is the complexted domain STFT of the music signal
%       Rows represent the kth frequency bin
%       Columns represent the order in time the STFT was taken
% times_in are the corresponding times of the center of the STFT window
% Fs is the sampling frequency of the music
% N_padding is the total number of points used for the STFT 
%       (actual points + Zero padding) = N_padding
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [detection_function times] = HFC(STFT_in, times_in, Fs, N_padding)
[nr number_of_transforms] = size(STFT_in);
%% Linearly Frequency Weighted Spectral Energy 

f_plot = -Fs/2:Fs/N_padding:Fs/2 - (Fs/N_padding);
f_plot = f_plot';
parfor k= 1:number_of_transforms
F_weight(:,k) = STFT_in(:,k).*f_plot;
end 
%% Alternate Power Calculation Option
% numeric integration vs summation
% power_weighted = cumtrapz(f_plot,abs(F_weight).^2,1); %Frequency Weighted Power, Cumulative integral
% power_weighted = power_weighted(end,:);
% energy = sum(abs(F_weight).^2,1);
% detection_function = energy;
%% Calculate Power by summing all amplitudes squared
detection_function = sum(abs(F_weight).^2,1);
times = times_in;

end



