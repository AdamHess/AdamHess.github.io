%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Master Project Sample File
%   Code Written by: Adam Hess
%   
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%This is a sample file of how to use the included functions
% Define variables
% take STFT
%  Apply Detection Functions
%  Pick Peaks
%  Calculate Error
clc;
clear all;
%% Load Music File and Onsets
 [music Fs] = wavread('music_prosemus_2.wav');
 onsets = load('onsets_prosemus_2.txt');

 
%% Processing 
 
wavplay(music,Fs, 'async')
% Define STFT parameters
%window Time
wTime = .05;
%2^ZP_exp additional zero padding
ZP_exp = 1;
%percentage of overlap (written as a number between 1 and 100)
Percent_overlap = 50;
%median filter Parameters
%scaling parameter
gamma = 1;
%filter length
filt_len = 5;
%constant threshold
C = 0;
%peak picking refractory period
refractory = .05;

%% Detection Algorithm
%take STFT
disp('Taking STFT')
[STFT_in times_in N_padding] = STFT_Music(music, Fs, wTime, Percent_overlap,ZP_exp);
disp('Applying Detection Functions');
% Apply Detection Function
[detection_function times] = SD(STFT_in,times_in);
%Optional Normalization
detection_function = (detection_function)/max(abs(detection_function));

disp('Peak Picking');
for i = 1:200
    C = .01*i;
%pick out peaks in detection function
[peak_time] = pickpeaks(detection_function, times, filt_len, gamma, C, refractory);
% Calculate Correct and false positive rate
[correct(i) false_pos(i)] = peak_error(peak_time, onsets, wTime);
end
disp('Ploting');
figure(1)
%some plotting
subplot(3,1,1)
musplot = sum(music,2);
mTime = 0:1/Fs:(length(musplot)/Fs)-(1/Fs);
plot(mTime, musplot);
title('Music Signal');
xlabel('Time')
ylabel('Amplitude');
subplot(3,1,2)
plot(times,detection_function/max(abs(detection_function)));
title('Detection Function (Normalized)');
xlabel('Time')
ylabel('Amplitude');

% Displaying one of the ranges of onsets
C = .03;
[peak_time] = pickpeaks(detection_function, times, filt_len, gamma, C, refractory);


subplot(3,1,3)
z = ones(length(peak_time));
stem(peak_time,z);
title('Detected Onsets');
xlabel('Time')
ylabel('N/A');

figure(2)
plot(false_pos, correct);
title('Error Detection Rates');
xlabel('False Positive')
ylabel('True Positive');

