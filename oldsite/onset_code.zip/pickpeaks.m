%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%[peak_time filt] = peakpick_music_median(detection_function, times, filt_len, gamma, C)
% returns times of peak as well as median filter used
% Outputs:
% peak_time is the time corresponding to the peaks in Detection_function
% filt is the filter threshold used for all points
%
% Inputs:
% detection_function - function with peaks which you wish to detect
% times - times corresponding to points of the detection function
% filt_len - length of median filter
% gamma - scaling factor for median filter
% C - constant minimum threshold
% refractory - minimum allowable time between peaks 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [peak_time filt] = pickpeaks(detection_function, times_in, filt_len, gamma, C, refractory)

    [fn_len nc] = size(detection_function);
    med_filt = medfilt1(detection_function,filt_len);%median filter function
    filt = gamma*med_filt + C; % thresholding function
   %see where the reduction function is above the threshold 
    thresholded = detection_function -filt; %subtract threshold

    [~, loc] = findpeaks(detection_function); %find peaks
    %find only the peak points where it is above the threshold filter
    index = find(thresholded(loc)>=0);
    index = loc(index);%use only these points for peak picking
    %eliminate redundant onsets bey introducing a refractory period. 
    [nr nc] = size(index);
    if (nc ~= 0)
      %eliminate spurious peaks by introducing a refractory period
      redundant_peak_times = times_in(index);
       temp_times(1) = redundant_peak_times(1);
       parfor k = 2: length(redundant_peak_times)
       diff_time = redundant_peak_times(k) - redundant_peak_times(k-1);
       if (diff_time < refractory)
           temp_times(k) = -1;
        else
            temp_times(k) = redundant_peak_times(k);
       end
       end
     peak_time = temp_times(find(temp_times>=0));
    else
        peak_time = [];
    end
end
