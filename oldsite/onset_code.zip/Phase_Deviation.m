%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%[detection_function times] = Phase_deviation(STFT_in, times_in)
% Outputs:
%  detection_function returns the values of the detection function applied
%  at times.
%  times are the times correspoinding to the detection_function features
%       times is a modified form of times_in, multiple initial points are
%       lost due to the initial conditions needed for the detection
%       algorithm.
% Inputs:
% STFT_in is the complexted domain STFT of the music signal
%       Rows represent the kth frequency bin
%       Columns represent the order in time the STFT was taken
% times_in are the corresponding times of the center of the STFT window
%      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [detection_function times] = Phase_Deviation(STFT_in, times_in)


[nr nc] = size(STFT_in);
F_phase = 0;
parfor k = 1:nc
    F_Phase(:,k) =  angle(STFT_in(:,k));%find phase of k FFT points for later use;
    %store all data in sample by sample chunks
end

%% phase deviation 
%simple phase calculation by averaging the phase deviation across all
% frequency bins
for k = 3:nc
    phi_k = F_Phase(:,k) - 2*F_Phase(:,k-1)+F_Phase(:,k-2);
    detection_function(k-2) = sum(abs(phi_k))/nr;
end
times = times_in(3:end);
end
