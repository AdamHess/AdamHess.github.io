Open the code for VQ_LBG_Test
1) vec_dim  controls the dimension of the VQ
2) bits controls the number of bits used for the  reconstruction level
3) M  defines the number of reconstruction levels (you can use this instead of bits for non powers of 2)