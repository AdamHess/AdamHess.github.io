% Adam Hess
% Data Compression Project
%will automatically play test file once completed 
%% LBG Algorithm (K-Means Clustering)
clearvars -except distort;
clc;
%% Number of RL and Dimension size control. 
vec_dim = 2; %Dimension of Vectors
bits = 8; %number of bits used to create reconstruction level;
M = 2^bits; %the number of reconstruction levels

%% LBG Parameters
N = 10000; %number of training vectors
iter = 100; % number of iterations
thresh = .0000001;%momentum threshold
perterb = [10^-5]; %amount of perterbation for empty cell problem
prev_dist = .000001;%initial condition



dim_size = vec_dim-1; 
%%  create training vectors
%load training files
%normalize each file
[file1 Fs] = wavread('bush.wav');
file1 = sum(file1,2);
file1 = file1/max(abs(file1));

[file2 Fs] = wavread('HelloSailor.wav');
file2 = sum(file2,2);
file2 = file2/max(abs(file2));

[file3 Fs] = wavread('exposure.wav');
file3 = sum(file3,2);
file3 = file3/max(abs(file3));

[file4 Fs] = wavread('Schiller.wav');
file4 = sum(file4,2);
file4 = file4/max(abs(file4));

data = cat(1, file1, file2, file3,file4);
clear file1 file2 file3 file4;
data_len = length(data);

%select random points from the conjoined file
%use these random points as training vectors

rand('seed', 100);
parfor k = 1:N;
    point = floor(data_len*rand);
    if ((point+dim_size)>data_len)
        point = data_len*rand;
        point = point + data_len*rand;
        point = floor(point/2);
    end
    training(k,:) = [data(point:point+dim_size);];
end


parfor k = 1:M;
    point = floor(data_len*rand);
    RL(k,:) = [data(point:point+dim_size);];
end


%% LBG Algorithm
B = [];
for k = 1:iter
        if (k/iter == .10)
        disp('10% complete');
    elseif (k/iter == .20)
        disp('20% complete');
    elseif (k/iter == .30)
        disp('30% complete');
        elseif (k/iter == .40)
        disp('40% complete');
        elseif (k/iter == .50)
        disp('50% complete');
        elseif (k/iter == .60)
        disp('60% complete');
        elseif (k/iter == .70)
        disp('70% complete');
        elseif (k/iter == .80)
        disp('80% complete');
        elseif (k/iter == .90)
        disp('90% complete');
        elseif (k/iter == 1)
        disp('100% complete');
    end    
    clear value classified vectors_in_region loc_count
    clear RL_next A B
  [value classified] =  min( dist(RL, training')); 
  parfor l = 1:M
      vectors_in_region = find(classified == l);
      loc_count(l) = length(vectors_in_region);
      region = training(vectors_in_region,:);
      RL_next(l,:) = sum(region)/loc_count(l); 
      A = RL(l,:);
      B = bsxfun(@minus, region,A)
      distort_LBG(l) = sum(sum(B.^2));
  end
  DK = sum(distort_LBG)/(vec_dim*N);
  rate_of_change = (DK-prev_dist)/prev_dist;
  if(rate_of_change < thresh)
      break;
  end
  RL = RL_next;
   % Eliminate zero element regions

    [Ind_r Index_of_zeros] = find(loc_count == 0);
    [Ind_nr Number_of_zeros] = size(Index_of_zeros);
    if (Number_of_zeros > 0)
         [C M] = max(loc_count);
         for qq = 1:Number_of_zeros
         RL(Index_of_zeros(qq),:) = RL(M,:) + perterb.*rand(1,vec_dim);
         end
    end
end



%% encode a sample file
[sample Fs] = wavread('testfile.wav'); % load Test file
sample = sum(sample,2);
sample = sample/abs(max(sample));

N_sample = floor(length(sample/vec_dim)); %number of sample points to take

N_length = floor(N_sample/vec_dim) - 5;;
parfor lq = 1:N_length
    starting = vec_dim*(lq-1)+1;
    speech_vector(lq,:) = [sample(starting:starting+dim_size)];
end

parfor lq = 1:N_length
    comp = dist(RL,speech_vector(lq,:)');
    [C I(lq)] = min(comp);
end
speech_hat = RL(I,:);
speech_recon = [];
for lq = 1:N_length;
    starting = vec_dim*(lq-1)+1;
    speech_recon(starting:starting+dim_size) = speech_hat(lq,:);
end
recon_size = length(speech_recon);
distort = sum(sum((sample(1:recon_size)-speech_recon').^2))/recon_size;

wavplay(speech_recon,Fs);
